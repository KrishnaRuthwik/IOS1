import UIKit

var greeting = "Hello, playground"

print("Hello", 10, 18.25)
//output space ,

var name = "Virat"
var grade = "71.71"
print("Hello, \(name) Your grade is \(grade)")

var proLan = "Swift";
print("I like the \(proLan) programming language")

print("hello")
print("888888888888")
print("88888888745939837888888", terminator:"$")
print(1,2,3,4,5,6)

//Worksheet 2 on constants and variables

var aweMessage = "This is Superb!"
print(aweMessage)
print("aweMessage")

var course1 = "iOS"
var course2 = "Java"
print(course1,course2)
print(course1,"-",course2)

var httpError  = (errorCode : 404  , errorMessage : "PageNotFound")
print(httpError)
print(httpError.errorCode , terminator : ": ")
print(httpError.errorMessage)

var name1 = ("Virat","Kohli")
var fName = name1.0
var lName = name1.1
print(fName , lName)

var origin = (x : 18 , y : 15)
var points = origin
print(points)

let city = (name : "Maryville" , population : 11,000)
let cityname = city.0
let population = city.1
print(cityname)
print(population)

let groceries = ("bread","onions",34.4)
print(groceries.0)
print(groceries.1)
print(groceries.2)
print(type(of: groceries))

var cricketKit = ("handGloves" ,"helmet",("bat","ball"))
print(cricketKit.0)
print(cricketKit.1)
print(cricketKit.2.0)
print(cricketKit.2.1)
